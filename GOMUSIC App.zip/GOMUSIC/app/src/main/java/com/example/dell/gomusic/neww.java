package com.example.dell.gomusic;

public class neww {
    private String mnews;

    public neww(String follownews) {
        mnews = follownews;
    }

    public String getFollowNews() {
        return mnews;
    }
}
