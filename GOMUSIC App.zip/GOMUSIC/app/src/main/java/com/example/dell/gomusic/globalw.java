package com.example.dell.gomusic;

public class globalw {

    private String mglobalevents;


    //Miwok translation for the word.


    //Creating a new word object.
    public globalw(String globalevents) {
        mglobalevents = globalevents;
    }

    public String getglobalevents() {
        return mglobalevents;
    }


}
