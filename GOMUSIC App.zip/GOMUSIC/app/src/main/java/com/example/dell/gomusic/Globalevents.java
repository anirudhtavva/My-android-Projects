package com.example.dell.gomusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class Globalevents extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_globalevents);
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(Globalevents.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.musicians));
        listView = (ListView) findViewById(R.id.eventColor1);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentevents = new Intent(Globalevents.this, Globalevents2.class);
                intentevents.putExtra("NEWS", listView.getItemAtPosition(position).toString());
                startActivity(intentevents);
            }
        });
        listView.setAdapter(mAdapter);


        Button backButton = (Button) findViewById(R.id.backg1);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Globalevents.this, MainActivity.class);
                startActivity(intent);
            }
        });


        ArrayList<globalw> events = new ArrayList<globalw>();
        events.add(new globalw("47th Hong Kong Arts Festival is coming. Go grab your tickets nows and enjoy every bit of music."));
        events.add(new globalw("VH1 SUPERSONIC ARCADE is fast approaching."));
        events.add(new globalw("MAHINDRA BLUES now in Mumbai. Meet the famous musician and have a great day filled with lots of music and fun."));
        events.add(new globalw("SUNBURN KLASSIQUE now in Goa. Coming on 23-24 February, 2019."));
        events.add(new globalw("SUNBURN ARENA WITH DJ SNAKE in the southern part of India from the 21st to 24th march, 2019. "));


        GlobalAdapter globalAdapter = new GlobalAdapter(this, events);
        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) findViewById(R.id.eventColor1);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(globalAdapter);
    }
}
