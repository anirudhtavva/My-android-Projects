package com.example.dell.gomusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Follow extends AppCompatActivity {

    ListView listView;
    ListView listView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow);
        listView = (ListView) findViewById(R.id.followmusicColor);
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(Follow.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.musicians));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(Follow.this, Follow2.class);
                intent.putExtra("A R Rahman", listView.getItemAtPosition(position).toString());
                startActivity(intent);
            }
        });
        listView.setAdapter(mAdapter);

        Button backButton = (Button) findViewById(R.id.back2);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Follow.this, MainActivity.class);
                startActivity(intent);
            }
        });

        ArrayList<Followw> follows = new ArrayList<Followw>();
        follows.add(new Followw("A R Rahman"));

        FollowAdapter adapter = new FollowAdapter(this, follows);
        ListView listView = (ListView) findViewById(R.id.followmusicColor);
        listView.setAdapter(adapter);
    }
}
