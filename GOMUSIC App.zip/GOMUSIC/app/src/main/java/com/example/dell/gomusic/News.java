package com.example.dell.gomusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class News extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(News.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.musicians));
        listView = (ListView) findViewById(R.id.newsColor);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentnews = new Intent(News.this, News2.class);
                intentnews.putExtra("NEWS", listView.getItemAtPosition(position).toString());
                startActivity(intentnews);
            }
        });
        listView.setAdapter(mAdapter);

        Button backButton = (Button) findViewById(R.id.backn1);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(News.this, MainActivity.class);
                startActivity(intent);
            }
        });


        ArrayList<neww> news = new ArrayList<neww>();
        news.add(new neww("Susan Boyle Announces New Album 'Ten'"));
        news.add(new neww("Royce Da 5'9\" Snipes at Kanye West & Wale on New Track 'Field Negro'"));
        news.add(new neww("Cage the Elephant Scores Best Alternative Songs Debut With 'Ready to Let Go'"));
        news.add(new neww("Lindsey Buckingham Suffers Vocal Cord Damage Following Emergency Open Heart Surgery"));
        news.add(new neww("Grammy Nominees Dua Lipa & Nipsey Hussle Shine at Warner Music Group's Pre-Grammy Party"));
        news.add(new neww("Ariana Grande releases fifth album and cancels appearing at the Grammys"));
        news.add(new neww("A host of celebrities have recorded their voices to add a touch of showbiz to a library's speaker system."));
        news.add(new neww("Jackson and George Harrison met on BBC Radio 1 in 1979 - and a recording has now been found."));
        news.add(new neww("'Blurred Lines' writers to pay $5m to Marvin Gaye family "));
        news.add(new neww("Indian Music Industry appoints Saregama’s Vikram Mehra as chairman"));
        news.add(new neww("Universal Music, Qyuki to jointly develop new music-based content"));
        news.add(new neww("War at the box office: 'Uri: The Surgical Strike' marching towards Rs 200-crore target"));
        news.add(new neww("Jazz, classical music help True Balance CEO relax & de-stress"));


        NewsAdapter newsAdapter = new NewsAdapter(this, news);
        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) findViewById(R.id.newsColor);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(newsAdapter);
    }
}
