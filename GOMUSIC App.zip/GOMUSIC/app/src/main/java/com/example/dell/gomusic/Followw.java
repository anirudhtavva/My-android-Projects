package com.example.dell.gomusic;

public class Followw {
    //Default translation for the word.
    private String mfollowmusician;


    //Miwok translation for the word.


    //Creating a new word object.
    public Followw(String followmusician) {
        mfollowmusician = followmusician;
    }

    public String getfollowMusician() {
        return mfollowmusician;
    }


}

