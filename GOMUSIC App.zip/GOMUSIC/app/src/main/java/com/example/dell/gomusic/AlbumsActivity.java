package com.example.dell.gomusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class AlbumsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_albums);
        Button nowPlayingCategoryButton = (Button) findViewById(R.id.nowPlayingButton);
        Button songsCategoryButton = (Button) findViewById(R.id.songsButton);
        Button playListsCategoryButton = (Button) findViewById(R.id.playlistsButton);

        LinearLayout showSongs = (LinearLayout) findViewById(R.id.albumInfo);
        nowPlayingCategoryButton.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Intent intent = new Intent(AlbumsActivity.this, NowSongPlayingActivity.class);
                startActivity(intent);
                finish();
            }

        });

        songsCategoryButton.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Intent intent = new Intent(AlbumsActivity.this, SongActivity.class);
                startActivity(intent);
                finish();
            }

        });

        playListsCategoryButton.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Intent intent = new Intent(AlbumsActivity.this, PlaylistActivity.class);
                startActivity(intent);
                finish();
            }

        });

        Button backButton = (Button) findViewById(R.id.backa);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlbumsActivity.this, Collections.class);
                startActivity(intent);
            }
        });

        showSongs.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                Intent intent = new Intent(AlbumsActivity.this, SongActivity.class);
                startActivity(intent);
                finish();
            }

        });
    }
}
