package com.example.dell.gomusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NowSongPlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_song_playing);

        Button albumCategoryButton = (Button) findViewById(R.id.albumsButton);
        Button songsCategoryButton = (Button) findViewById(R.id.songsButton);
        Button playListsCategoryButton = (Button) findViewById(R.id.playlistsButton);

        albumCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NowSongPlayingActivity.this, AlbumsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        Button backButton = (Button) findViewById(R.id.backn);
        backButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NowSongPlayingActivity.this, Collections.class);
                startActivity(intent);
            }
        });
        songsCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NowSongPlayingActivity.this, SongActivity.class);
                startActivity(intent);
                finish();
            }
        });

        playListsCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NowSongPlayingActivity.this, PlaylistActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
