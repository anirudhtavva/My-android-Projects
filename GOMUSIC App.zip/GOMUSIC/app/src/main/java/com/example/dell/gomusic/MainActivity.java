package com.example.dell.gomusic;

import android.app.LauncherActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


import com.example.dell.gomusic.Collections;
import com.example.dell.gomusic.Globalevents;
import com.example.dell.gomusic.News;
import com.example.dell.gomusic.R;

public class MainActivity extends AppCompatActivity {

    Button buttonView;
    //Toolbar toolbar;
    //Set an onClickListener on that View


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Find the View that shows the numbers category
        Button collections = (Button) findViewById(R.id.collection);
        //TextView families = (TextView) findViewById(R.id.family);
        //toolbar = (Toolbar) findViewById(R.id.toolbar);
        //toolbar.setTitle(getResources().getString(R.string.app_name));

// Set a click listener on that View
        collections.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent collectionsIntent = new Intent(MainActivity.this, Collections.class);
                startActivity(collectionsIntent);
            }

        });
        Button news = (Button) findViewById(R.id.NEWS);
        news.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Intent newsIntent = new Intent(MainActivity.this, News.class);
                startActivity(newsIntent);
            }

        });
        // Find the View that shows the family category
        Button events = (Button) findViewById(R.id.event);
        // Set a click listener on that View
        events.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the family category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FamilyActivity}
                Intent eventIntent = new Intent(MainActivity.this, Globalevents.class);
                // Start the new activity
                startActivity(eventIntent);
            }
        });

        // Find the View that shows the family category
        Button fmusic = (Button) findViewById(R.id.followmusic);
        // Set a click listener on that View
        fmusic.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the family category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link FamilyActivity}
                Intent followIntent = new Intent(MainActivity.this, Follow.class);
                // Start the new activity
                startActivity(followIntent);
            }
        });


    }
}




