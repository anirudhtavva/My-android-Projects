package com.example.dell.americanfootballscorecounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    /**
     * Displays the given score for Team A.
     */
    int score1=0;
    int score2=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void resetScore(View view) {
        score1 = 0;
        score2 = 0;
        displayForTeamA(score1);
        displayForTeamB(score2);
    }
    public void d1(View view){

        displayForTeamA(score1+6);
        score1+=6;

    }
    public void d2(View view){

        displayForTeamA(score1+3);
        score1+=3;
    }
    public void d3(View view){

        displayForTeamA(score1+2);
        score1+=2;
    }
    public void d4(View view){

        displayForTeamA(score1+2);
        score1+=2;
    }
    public void d5(View view){

        displayForTeamA(score1+1);
        score1+=1;
    }

    public void e1(View view){

        displayForTeamB(score2+6);
        score2+=6;
    }
    public void e2(View view){

        displayForTeamB(score2+3);
        score2+=3;
    }
    public void e3(View view){

        displayForTeamB(score2+2);
        score2+=2;
    }
    public void e4(View view){

        displayForTeamB(score2+2);
        score2+=2;
    }
    public void e5(View view){

        displayForTeamB(score2+1);
        score2+=1;
    }

    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));

    }
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
}

