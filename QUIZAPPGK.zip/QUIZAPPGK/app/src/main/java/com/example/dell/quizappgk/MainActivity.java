package com.example.dell.quizappgk;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final long START_TIME_IN_MILLIS = 300000; //10 minutes.

    private TextView mTextViewCountDown;
    private Button mButtonStartPause;
    private Button mButtonReset;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    EditText editText;
    TextView textView;
    RadioButton radioButton;
    RadioButton radioButton1;
    CheckBox checkBox1, checkBox2, checkBox3, checkBox4;
    int x = 0;
    boolean flag4 = false, flag1 = false, flag2 = false, flag3 = false,flag5 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.score);
        textView.setText("Score : " + x);
        mTextViewCountDown = findViewById(R.id.text_view_countdown);
        mButtonStartPause = findViewById(R.id.button_start_pause);
        mButtonReset = findViewById(R.id.button_reset);
        mButtonStartPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mTimerRunning){
                    pauseTimer();
                }  else{
                    startTimer();
                }
            }
        });
        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
        updateCountDownText();
    }
    private void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                mButtonStartPause.setText("Start");
                mButtonStartPause.setVisibility(View.INVISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, "Time up! Please stop the quiz!!! Your Score is " + x, Toast.LENGTH_SHORT).show();
            }
        }.start();
        mTimerRunning = true;
        mButtonStartPause.setText("pause");
        mButtonReset.setVisibility(View.INVISIBLE);
    }
    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        mButtonStartPause.setText("Start");
        mButtonReset.setVisibility(View.VISIBLE);
    }
    private void resetTimer() {
        mTimeLeftInMillis = START_TIME_IN_MILLIS;
        updateCountDownText();
        mButtonReset.setVisibility(View.INVISIBLE);
        mButtonStartPause.setVisibility(View.VISIBLE);
    }
    private void updateCountDownText(){
        int minutes = (int) (mTimeLeftInMillis/1000)/60;
        int seconds = (int) (mTimeLeftInMillis/1000)%60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        mTextViewCountDown.setText(timeLeftFormatted);
    }


    public void answer1(View view) {
        textView = (TextView) findViewById(R.id.score);
        radioButton = (RadioButton) findViewById(R.id.tcpip);
        if (radioButton.isChecked()) {
            if (!flag1) {
                x = x + 10;
                textView.setText("Score : " + x);
                flag1 = true;
                Toast.makeText(this, "Correct Answer" + "\n" + "You get 10 marks.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Incorrect Answer " + "\n" + "Correct Answer is : TCP/IP", Toast.LENGTH_SHORT).show();
        }
    }

    public void answer2(View view) {

        textView = (TextView) findViewById(R.id.score);
        checkBox1 = (CheckBox) findViewById(R.id.pascal);
        checkBox2 = (CheckBox) findViewById(R.id.smalltalk);
        checkBox3 = (CheckBox) findViewById(R.id.java);
        checkBox4 = (CheckBox) findViewById(R.id.python);

        if ((checkBox1.isChecked() && checkBox2.isChecked()) && (!checkBox3.isChecked() && !checkBox4.isChecked())) {// {
            if (!flag2) {
                x = x + 10;
                textView.setText("Score : " + x);
                flag2 = true;
                Toast.makeText(this, "Correct Answer" + "\n" + "10 marks is added.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
        }
            else {
                Toast.makeText(this, "Incorrect Answer " + "\n" + "Correct Answer is : Pascal and Smalltalk", Toast.LENGTH_SHORT).show();
            }
        }

        public void answer3(View view)
        {
            textView = (TextView) findViewById(R.id.score);
            radioButton1 = (RadioButton) findViewById(R.id.Threepoint3);

            if(radioButton1.isChecked()){
                if(!flag3){
                    x = x + 10;
                    textView.setText("Score: " + x);
                    flag3 = true;
                    Toast.makeText(this, "Correct Answer" + "\n" + "You get 10 marks.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, "Correcy Answer", Toast.LENGTH_SHORT).show();
            }
            else{
                //x -= 10;
                //textView.setText("Score: " + x);
                Toast.makeText(this, "Incorrect Answer." + "\n" + "Correct Answer is : 3.3.0", Toast.LENGTH_SHORT).show();
                //return;
            }
        }
    public void answer4(View view) {

        textView = (TextView) findViewById(R.id.score);
        editText = (EditText) findViewById(R.id.ansedit);
        String content = editText.getText().toString();
        if (content.equals(null) || content.length() == 0) {
            Toast.makeText(this, "Please type Your Answer", Toast.LENGTH_SHORT).show();
            return;
        }
        else if (content.equalsIgnoreCase("1911")) {
            if (!flag4) {
                x = x + 10;
                textView.setText("Score : " + x);
                flag4 = true;
                Toast.makeText(this, "Correct Answer" + "\n" + "10 marks is added.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Incorrect Answer" + "\n" + "Correct Answer is : 1911", Toast.LENGTH_SHORT).show();
        }
    }


    public void answer5(View view) {

        textView = (TextView) findViewById(R.id.score);

        editText = (EditText) findViewById(R.id.personwrite);

        String monument = editText.getText().toString();

        if (monument.equals(null) || monument.length() == 0) {

            Toast.makeText(this, "Please Type Your Answer", Toast.LENGTH_SHORT).show();

            return;

        } else if (monument.equalsIgnoreCase("1998"))

                 {

            if (!flag5) {

                x = x + 10;

                textView.setText("Score : " + x);

                flag5 = true;

                Toast.makeText(this, "Correct Answer" + "\n" + "10 marks is added.", Toast.LENGTH_SHORT).show();

                return;

            }

            Toast.makeText(this, "Correct Answer", Toast.LENGTH_SHORT).show();

        } else {

            Toast.makeText(this, "Incorrect Answer" + "\n" + "Correct Answer is : 1998", Toast.LENGTH_SHORT).show();

        }

    }


}





